# OxiPNG

- Source: <https://github.com/shssoichiro/oxipng>
- Version: v3.0.0
- License: MIT
