# PNG

- Source: https://github.com/GoogleChromeLabs/squoosh
- Version: v1.12.0
- License: Apache-2.0
