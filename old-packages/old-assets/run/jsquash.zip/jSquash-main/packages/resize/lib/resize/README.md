# Resize

- Source: <https://github.com/PistonDevelopers/resize>
- Version: v0.3.0
- License: MIT
