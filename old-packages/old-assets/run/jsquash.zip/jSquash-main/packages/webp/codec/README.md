# WebP

- Source: https://github.com/webmproject/libwebp
- Version: v1.0.2	
- License: BSD
